import "./../styles/globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Frank Denette, Realtor® | Smooth Sailing, LLC | Keller Williams Coastal Realty",
  description: "Official website for Frank Denette, Realtor® — Smooth Sailing, LLC at Keller Williams Coastal Realty. Helping Rhode Island homeowners navigate today's sales with clarity, calmness and professionalism",
  metadataBase: new URL("https://frankdenette.com"),
  alternates: {
    canonical: "https://frankdenette.com",
    languages: {"en-US": "https://frankdenette.com"}
  },
  openGraph: {
    title: "Frank Denette, Realtor® | Smooth Sailing, LLC | Keller Williams Coastal Realty",
    description: "Official website for Frank Denette, Realtor® — Smooth Sailing, LLC at Keller Williams Coastal Realty. Helping Rhode Island homeowners navigate today's sales with clarity, calmness and professionalism",
    url: "https://frankdenette.com",
    siteName: "Smooth Sailing, LLC",
    locale: "en_US",
    type: "website"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="container py-5 flex items-center justify-between">
          <div className="font-bold text-xl">Smooth Sailing · Frank Denette, Realtor®</div>
          <nav className="hidden md:flex gap-6 text-sm">
            <a href="/sell">Sell</a>
            <a href="/buy">Buy</a>
            <a href="/value">Home Value</a>
            <a href="/contact">Contact</a>
          </nav>
        </header>
        <main>{children}</main>
        <footer className="container py-10 text-sm">
          © {new Date().getFullYear()} Smooth Sailing, LLC · Keller Williams Coastal Realty · Frank & Esther Denette | Warwick, RI · RI/CT/MA Licensed
        </footer>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={
            __html: JSON.stringify({
              "@context":"https://schema.org",
              "@type":"RealEstateAgent",
              "name":"Frank Denette, Realtor®",
              "memberOf": {"@type":"Organization","name":"Smooth Sailing, LLC"},
              "url":"https://frankdenette.com",
              "sameAs": ["https://frank.smoothsailingri.com", "https://frankdenette.com"],
              "areaServed":["Rhode Island","Connecticut","Massachusetts"],
              "availableLanguage": ["English"],
              "address":{"@type":"PostalAddress","streetAddress":"501 Centerville Rd, Suite 201","addressLocality":"Warwick","addressRegion":"RI","postalCode":"02886"}
            })
          }
        />
      </body>
    </html>
  );
}
