export const metadata = {
  title: "Sell Your Rhode Island Home | Smooth Sailing, LLC",
  description: "Pricing precision + premium marketing to sell smoothly and profitably."
};

export default function Sell() {
  return (
    <div className="container py-10 space-y-8">
      <h1 className="text-4xl font-bold">Sell your Rhode Island home—smoothly and profitably.</h1>
      <section className="grid md:grid-cols-3 gap-6">
        {[
          ["Pricing Strategy","Comparable sales + absorption trends; clear list-to-close plan."],
          ["Marketing Stack","Pro photos, drone, 3D tours, staging tips, targeted ads."],
          ["Process & Communication","Weekly updates; one point of contact; vendor coordination."]
        ].map(([h,p],i)=>(
          <div key={i} className="card"><h3 className="font-semibold mb-2">{h}</h3><p className="text-sm">{p}</p></div>
        ))}
      </section>
      <a className="btn btn-primary" href="/value">Request your Captain’s Value Report</a>
      <section className="prose max-w-none">
        <h2 className="text-2xl font-semibold mt-8">FAQ</h2>
        <ul className="list-disc pl-6">
          <li>How fast can we list? With photos/3D/disclosures ready, often within 72 hours.</li>
          <li>What if the appraisal is low? We prep comps, negotiate, and explore gap options.</li>
          <li>Can I sell as-is? Yes—let’s discuss the best approach for your goals.</li>
        </ul>
      </section>
    </div>
  );
}
