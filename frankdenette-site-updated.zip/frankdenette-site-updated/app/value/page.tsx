"use client";

import { useSearchParams } from "next/navigation";
import { useMemo } from "react";

export const metadata = {
  title: "Home Value | Captain’s Value Report",
  description: "Instant estimate plus human review—clear pricing strategy and next steps."
};

export default function Value() {
  const params = useSearchParams();
  const address = params.get("address") || "";
  const name = params.get("name") || "";
  const email = params.get("email") || "";
  const phone = params.get("phone") || "";

  const summary = useMemo(()=>{
    return {
      address, name, email, phone,
      notes: "We’ll text you shortly with next steps and schedule a walkthrough if you’d like a refined CMA."
    };
  }, [address, name, email, phone]);

  return (
    <div className="container py-10 space-y-6">
      <h1 className="text-3xl font-bold">Captain’s Value Report — Request Received</h1>
      <p>Thanks{ name ? `, ${name}` : ""}! We’ll prepare a clear strategy tailored to your timeline and goals.</p>
      <div className="card">
        <h3 className="font-semibold mb-2">Your Details</h3>
        <pre className="bg-gray-50 rounded-lg p-4 overflow-auto text-sm">{JSON.stringify(summary, null, 2)}</pre>
      </div>
      <a className="btn btn-primary" href="/contact">Book a 15‑min call</a>
    </div>
  );
}
