export default function Home() {
  return (
    <div className="container grid md:grid-cols-2 gap-10 items-center py-10">
      <section>
        <h1 className="text-4xl md:text-5xl font-bold leading-tight">
          Navigate today’s market with clarity, calmness, and professionalism.
        </h1>
        <p className="mt-4 text-lg">
          14+ years of Rhode Island experience and a proven, step‑by‑step plan to sell with confidence.
        </p>
        <div className="mt-6 flex gap-3">
          <a className="btn btn-primary" href="/value">Get Your Value</a>
          <a className="btn btn-outline" href="/contact">Book a 15‑min call</a>
        </div>
        <div className="grid md:grid-cols-3 gap-4 mt-10">
          {["Experience you can feel", "Strategic pricing & marketing", "Vendor network ready"].map((t,i)=>(
            <div key={i} className="card">{t}</div>
          ))}
        </div>
      </section>
      <section className="card">
        <h3 className="text-xl font-semibold mb-2">Get Your Captain’s Value Report</h3>
        <p className="text-sm mb-4">
          A clear pricing strategy, timeline, and next steps—custom to your home and goals.
        </p>
        <form className="grid gap-3" action="/value" method="get">
          <input name="address" placeholder="Property Address" className="border rounded-lg px-3 py-2" required />
          <input name="name" placeholder="Name" className="border rounded-lg px-3 py-2" required />
          <input name="email" type="email" placeholder="Email" className="border rounded-lg px-3 py-2" required />
          <input name="phone" placeholder="Phone" className="border rounded-lg px-3 py-2" />
          <button className="btn btn-primary" type="submit">See My Options</button>
        </form>
        <p className="text-xs mt-2">
          By submitting, you agree to be contacted by phone, text, or email. Carrier rates may apply.
        </p>
      </section>
    </div>
  );
}
