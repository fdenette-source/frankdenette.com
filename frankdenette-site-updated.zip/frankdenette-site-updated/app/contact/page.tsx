export const metadata = {
  title: "Contact Frank Denette | Smooth Sailing, LLC",
  description: "Call, text, or email. Let’s chart your best route."
};

export default function Contact() {
  return (
    <div className="container py-10 space-y-6">
      <h1 className="text-3xl font-bold">Contact</h1>
      <div className="card">
        <p><strong>Phone:</strong> (401) 248-4644</p>
        <p><strong>Email:</strong> fdenette@gmail.com</p>
        <p><strong>Office:</strong> 501 Centerville Rd, Suite 201, Warwick, RI 02886</p>
      </div>
      <p className="text-sm">Prefer a callback? Tap the button below and pick a time that works.</p>
      <a className="btn btn-outline" href="#">Book a 15‑min call</a>
    </div>
  );
}
