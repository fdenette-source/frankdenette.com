# frankdenette.com — Updated Starter

Meta and homepage updated for clarity/calm professionalism.
